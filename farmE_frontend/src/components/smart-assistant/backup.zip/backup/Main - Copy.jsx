import "./Main.css";
import { assets } from "../../assets/smart-assistant/assets";
import React, { useEffect, useRef, useState } from "react";
import axios from "axios";

const SmartAssistantMain = () => {
  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);
  const [fileNames, setFileNames] = useState([]);
  const [imageFiles, setImageFiles] = useState([]);
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [showChat, setShowChat] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [chatbotType, setChatbotType] = useState("farmE"); // Default is farmE chatbot

  useEffect(() => {
    setShowChat(
      messages.length > 0 || fileNames.length > 0 || imageFiles.length > 0
    );
  }, [messages, fileNames, imageFiles]);

  const handleImageClick = () => {
    fileInputRef.current.click();
  };

  const handleImageClick2 = () => {
    imageInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const files = Array.from(event.target.files);
    const newFiles = [];
    const newImages = [];

    files.forEach((file) => {
      if (file.type.startsWith("image/")) {
        newImages.push(file);
      } else if (file.type === "application/pdf") {
        newFiles.push(file);
      } else {
        console.warn(`Unsupported file type: ${file.type}`);
      }
    });

    setFileNames((prevFileNames) => [...prevFileNames, ...newFiles]);
    setImageFiles((prevImageFiles) => [...prevImageFiles, ...newImages]);
  };

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleSendMessage = async () => {
    setIsTyping(true);
    if (
      inputValue.trim() !== "" ||
      (fileNames.length > 0 && chatbotType === "farmE") ||
      (imageFiles.length > 0 && chatbotType === "farmE")
    ) {
      const userMessage = {
        type: "user",
        content: inputValue,
        files: fileNames,
        images: imageFiles,
      };
      setMessages([...messages, userMessage]);
      setInputValue("");

      try {
        const formData = new FormData();
        formData.append("text_input", inputValue);

        if (chatbotType === "farmE") {
          fileNames.forEach((file, index) => {
            if (file.type === "application/pdf") {
              formData.append(`pdfs`, file);
            }
          });

          imageFiles.forEach((image, index) => {
            if (image.type.startsWith("image/")) {
              formData.append(`images`, image);
            }
          });
        }

        const response = await axios.post(
          `http://localhost:8000/process_input_${chatbotType}/`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            }
          }
        );

        const botResponse = {
          type: "bot",
          content: response.data.response,
        };
        setMessages((prev) => [...prev, botResponse]);
      } catch (error) {
        console.error("Error in handleSendMessage:", error);
        const errorResponse = {
          type: "bot",
          content: `Error: ${error.response ? JSON.stringify(error.response.data) : error.message}`,
        };
        setMessages((prev) => [...prev, errorResponse]);
      } finally {
        setIsTyping(false);
        setFileNames([]);
        setImageFiles([]);
      }
    }
  };

  const removeFile = (index, type) => {
    if (type === "file") {
      setFileNames((prevFiles) => prevFiles.filter((_, i) => i !== index));
    } else if (type === "image") {
      setImageFiles((prevImages) => prevImages.filter((_, i) => i !== index));
    }
  };

  return (
    <div className="main">
      <div className="nav">
        <div className="chatbot-selector">
          <label>
            <input
              type="radio"
              value="farmE"
              checked={chatbotType === "farmE"}
              onChange={() => setChatbotType("farmE")}
            />
            farmE Chatbot
          </label>
          <label>
            <input
              type="radio"
              value="pdfRAG"
              checked={chatbotType === "pdfRAG"}
              onChange={() => setChatbotType("pdfRAG")}
            />
            PDF RAG Chatbot
          </label>
        </div>
      </div>
      <div className="main-container">
        <div
          className="initial-chat"
          style={{ display: showChat ? "none" : "block" }}
        >
          <div className="greet">
            <p>
              <span>Hello, I'm your farmAI</span>
            </p>
            <p>How can I help you today?</p>
          </div>
          <div className="cards">
            <div className="card">
              <p>Where should I plan to build an agrivoltaic farm?</p>
              <img src={assets.compass_icon} alt="" />
            </div>
            <div className="card">
              <p>What plant should I plant with the solar panel?</p>
              <img src={assets.bulb_icon} alt="" />
            </div>
            <div className="card">
              <p>What is my ROI?</p>
              <img src={assets.message_icon} alt="" />
            </div>
            <div className="card">
              <p>Write me the report</p>
              <img src={assets.code_icon} alt="" />
            </div>
          </div>
        </div>
        <div
          className="chat-container"
          style={{ display: showChat ? "block" : "none", minHeight: "55vh" }}
        >
          <div className="messages">
            {messages.map((message, index) => (
              <div key={index} className={`message ${message.type}`}>
                {message.type === "user" && (
                  <div className="user-message" style={{ textAlign: "right" }}>
                    <p>
                      {message.files.map((file, fileIndex) => (
                        <div
                          key={fileIndex}
                          style={{
                            padding: "8px",
                            marginLeft: "auto",
                          }}
                        >
                          <img
                            src={assets.file_icon}
                            alt="Upload"
                            style={{ width: "18px", marginRight: "5px" }}
                          />
                          <span>{file.name}</span>
                        </div>
                      ))}
                      {message.images.map((image, imgIndex) => (
                        <div
                          key={imgIndex}
                          style={{
                            padding: "8px",
                            marginLeft: "auto",
                          }}
                        >
                          <img
                            src={URL.createObjectURL(image)}
                            alt="Upload"
                            style={{ width: "200px", marginRight: "5px" }}
                          />
                        </div>
                      ))}
                      <span
                        style={{
                          padding: "10px",
                          borderRadius: "15px",
                          backgroundColor: "#D3D3D3",
                        }}
                      >
                        {message.content}
                      </span>
                    </p>
                  </div>
                )}
                {message.type === "bot" && (
                  <div
                    className="bot-message"
                    dangerouslySetInnerHTML={{ __html: message.content }}
                  ></div>
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="margin-top-30" style={{ marginTop: "30%" }}>
          {isTyping && <div className="loading">Loading...</div>}
          {fileNames.length > 0 && (
            <div className="file-preview">
              {fileNames.map((file, index) => (
                <div key={index} className="file-item">
                  <span>{file.name}</span>
                  <button onClick={() => removeFile(index, "file")}>
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
          {imageFiles.map((image, imgIndex) => (
            <div key={imgIndex} className="file-item">
              <div
                style={{
                  padding: "8px",
                  marginLeft: "auto",
                }}
              >
                <img
                  src={URL.createObjectURL(image)}
                  alt="Upload"
                  style={{ width: "100px", marginRight: "5px" }}
                />
              </div>
              <button onClick={() => removeFile(imgIndex, "image")}>
                Remove
              </button>
            </div>
          ))}
          <div className="search-box">
            <input
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              placeholder="Enter a prompt here"
            />
            <div className="input-actions">
              {chatbotType === "farmE" && (
                <>
                  <img
                    src={assets.attach_icon}
                    alt="Attach"
                    onClick={handleImageClick}
                  />
                  <img
                    src={assets.attach_image}
                    alt="Attach"
                    onClick={handleImageClick2}
                  />
                </>
              )}
              <button className="send-button" onClick={handleSendMessage}>
                Send
              </button>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              style={{ display: "none" }}
              accept="application/pdf,image/*"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SmartAssistantMain;
